# machine-learning-projects
Machine Learning Projects

Machine Learning Project 1 - House Price Prediction - Part 1
<br>https://www.youtube.com/watch?v=etfJ6yNVqu4

Machine Learning Project 1 - House Price Prediction - Part 2
<br>https://www.youtube.com/watch?v=DCFIvqQe0hI

Machine Learning Project 1 - House Price Prediction - Part 3
<br>https://www.youtube.com/watch?v=vK8CEEZZfVA

Machine Learning Project 2 - Heart Disease Prediction - Part 1
<br>https://www.youtube.com/watch?v=Yy1b85LbdHw

Machine Learning Project 2 - Heart Disease Prediction - Part 2
<br>https://www.youtube.com/watch?v=ImzBncpCPns

Machine Learning Project 3 - Predict Term Deposit Subscriptions
<br>https://www.youtube.com/watch?v=LanIDRcm5x8
